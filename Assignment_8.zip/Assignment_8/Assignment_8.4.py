# Delete set of keys from a dictionary

# Given:

sampleDict = {"name": "Kelly","age":25,"salary": 8000,"city": "New york"}
keysToRemove = ["name", "salary"]

sampleDict.pop("name")
sampleDict.pop("salary")
print(sampleDict)
