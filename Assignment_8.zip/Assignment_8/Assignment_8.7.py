# 7. display the key of a maximum value from the following dictionary

GivenDict = {'Physics': 82,'Math': 65,'history': 75}
print("The key of a maximum value is:",GivenDict[max(GivenDict)])